import warnings

warnings.warn('You are loading items from legacy code. This is code that is to be decommissioned. Proceed with caution.', stacklevel=2)