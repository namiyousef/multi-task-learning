import json

path = '../datasets/75seg25bb.json'

with open(path, 'r') as f:
    data = json.load(f)

val = data['loss']['val']
train = data['loss']['train']

import matplotlib.pyplot as plt
epochs = range(len(val['bb']))
plt.plot(epochs, train['seg'])
plt.plot(epochs,val['seg'])
plt.show()